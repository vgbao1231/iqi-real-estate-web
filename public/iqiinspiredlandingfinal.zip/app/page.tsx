"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FadeIn, SlideIn, ScaleIn } from "@/components/animations"
import { ThemeToggle } from "@/components/theme-toggle"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu"
import {
  Phone,
  Mail,
  MapPin,
  Star,
  Users,
  Award,
  Globe,
  TrendingUp,
  Building,
  Palmtree,
  Handshake,
  ChevronRight,
  Menu,
  X,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { useState } from "react"

export default function HomePage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">IQI</span>
              </div>
              <span className="font-bold text-xl">IQI Vietnam</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-foreground hover:text-orange-600 transition-colors">
                Trang chủ
              </Link>

              <NavigationMenu>
                <NavigationMenuList>
                  <NavigationMenuItem>
                    <NavigationMenuTrigger className="group relative text-foreground hover:text-orange-600 transition-colors">
                      Sản phẩm
                      <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-orange-500 to-orange-600 transition-all duration-300 group-hover:w-full"></div>
                    </NavigationMenuTrigger>
                    <NavigationMenuContent>
                      <div className="grid w-[400px] gap-3 p-4">
                        <NavigationMenuLink asChild>
                          <Link
                            href="/products/international"
                            className="group block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                          >
                            <div className="flex items-center space-x-2">
                              <Globe className="w-4 h-4 text-blue-600" />
                              <div className="text-sm font-medium leading-none group-hover:text-orange-600 transition-colors">
                                BDS Quốc tế
                                <div className="w-0 h-0.5 bg-gradient-to-r from-orange-500 to-orange-600 transition-all duration-300 group-hover:w-full"></div>
                              </div>
                            </div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              Bất động sản cao cấp tại các quốc gia phát triển
                            </p>
                          </Link>
                        </NavigationMenuLink>
                        <NavigationMenuLink asChild>
                          <Link
                            href="/products/vietnam"
                            className="group block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                          >
                            <div className="flex items-center space-x-2">
                              <Building className="w-4 h-4 text-orange-600" />
                              <div className="text-sm font-medium leading-none group-hover:text-orange-600 transition-colors">
                                BDS Việt Nam
                                <div className="w-0 h-0.5 bg-gradient-to-r from-orange-500 to-orange-600 transition-all duration-300 group-hover:w-full"></div>
                              </div>
                            </div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              Căn hộ, nhà phố, đất nền tại TP.HCM và Hà Nội
                            </p>
                          </Link>
                        </NavigationMenuLink>
                        <NavigationMenuLink asChild>
                          <Link
                            href="/products/resort"
                            className="group block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                          >
                            <div className="flex items-center space-x-2">
                              <Palmtree className="w-4 h-4 text-green-600" />
                              <div className="text-sm font-medium leading-none group-hover:text-orange-600 transition-colors">
                                BDS nghỉ dưỡng
                                <div className="w-0 h-0.5 bg-gradient-to-r from-orange-500 to-orange-600 transition-all duration-300 group-hover:w-full"></div>
                              </div>
                            </div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              Resort, biệt thự biển, condotel cao cấp
                            </p>
                          </Link>
                        </NavigationMenuLink>
                        <NavigationMenuLink asChild>
                          <Link
                            href="/partners"
                            className="group block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                          >
                            <div className="flex items-center space-x-2">
                              <Handshake className="w-4 h-4 text-purple-600" />
                              <div className="text-sm font-medium leading-none group-hover:text-orange-600 transition-colors">
                                Đối tác
                                <div className="w-0 h-0.5 bg-gradient-to-r from-orange-500 to-orange-600 transition-all duration-300 group-hover:w-full"></div>
                              </div>
                            </div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              Mạng lưới đối tác quốc tế và trong nước
                            </p>
                          </Link>
                        </NavigationMenuLink>
                      </div>
                    </NavigationMenuContent>
                  </NavigationMenuItem>
                </NavigationMenuList>
              </NavigationMenu>

              <div className="group relative">
                <Link href="/about" className="text-foreground hover:text-orange-600 transition-colors">
                  Về chúng tôi
                </Link>
                <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-orange-500 to-orange-600 transition-all duration-300 group-hover:w-full"></div>
              </div>

              <div className="group relative">
                <Link href="/news" className="text-foreground hover:text-orange-600 transition-colors">
                  Tin tức
                </Link>
                <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-orange-500 to-orange-600 transition-all duration-300 group-hover:w-full"></div>
              </div>

              <div className="group relative">
                <Link href="/contact" className="text-foreground hover:text-orange-600 transition-colors">
                  Liên hệ
                </Link>
                <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-orange-500 to-orange-600 transition-all duration-300 group-hover:w-full"></div>
              </div>
            </nav>

            {/* Right side */}
            <div className="flex items-center space-x-4">
              <ThemeToggle />
              <Link href="/consultation">
                <Button className="hidden md:inline-flex bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700">
                  Tư vấn miễn phí
                </Button>
              </Link>

              {/* Mobile menu button */}
              <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-t bg-background"
            >
              <div className="px-4 py-4 space-y-4">
                <Link
                  href="/"
                  className="block py-2 text-foreground hover:text-orange-600 transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Trang chủ
                </Link>

                <div className="space-y-2">
                  <div className="font-medium text-foreground">Sản phẩm</div>
                  <div className="pl-4 space-y-2">
                    <Link
                      href="/products/international"
                      className="block py-1 text-sm text-muted-foreground hover:text-orange-600 transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      BDS Quốc tế
                    </Link>
                    <Link
                      href="/products/vietnam"
                      className="block py-1 text-sm text-muted-foreground hover:text-orange-600 transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      BDS Việt Nam
                    </Link>
                    <Link
                      href="/products/resort"
                      className="block py-1 text-sm text-muted-foreground hover:text-orange-600 transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      BDS nghỉ dưỡng
                    </Link>
                    <Link
                      href="/partners"
                      className="block py-1 text-sm text-muted-foreground hover:text-orange-600 transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Đối tác
                    </Link>
                  </div>
                </div>

                <Link
                  href="/about"
                  className="block py-2 text-foreground hover:text-orange-600 transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Về chúng tôi
                </Link>
                <Link
                  href="/news"
                  className="block py-2 text-foreground hover:text-orange-600 transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Tin tức
                </Link>
                <Link
                  href="/contact"
                  className="block py-2 text-foreground hover:text-orange-600 transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Liên hệ
                </Link>
                <Link href="/consultation" onClick={() => setMobileMenuOpen(false)}>
                  <Button className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700">
                    Tư vấn miễn phí
                  </Button>
                </Link>
              </div>
            </motion.div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-orange-50 to-orange-100 dark:from-orange-950/20 dark:to-orange-900/20 overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="container mx-auto px-4 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <FadeIn>
              <div>
                <Badge className="mb-4 bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300">
                  ĐỐI TÁC TIN CẬY
                </Badge>
                <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
                  Chuyên gia{" "}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-orange-600">
                    Bất động sản
                  </span>{" "}
                  hàng đầu
                </h1>
                <p className="text-xl text-muted-foreground mb-8 max-w-lg">
                  Với hơn 15 năm kinh nghiệm, IQI Vietnam mang đến cho bạn những cơ hội đầu tư bất động sản tốt nhất tại
                  Việt Nam và quốc tế.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Link href="/consultation">
                      <Button
                        size="lg"
                        className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
                      >
                        Tư vấn miễn phí
                        <ChevronRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                  </motion.div>
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Link href="/products/vietnam">
                      <Button
                        size="lg"
                        variant="outline"
                        className="border-orange-200 hover:bg-orange-50 dark:border-orange-800 dark:hover:bg-orange-950/20 bg-transparent"
                      >
                        Xem dự án
                      </Button>
                    </Link>
                  </motion.div>
                </div>
              </div>
            </FadeIn>
            <SlideIn direction="right">
              <div className="relative">
                <motion.div whileHover={{ scale: 1.02 }} transition={{ duration: 0.3 }} className="relative z-10">
                  <Image
                    src="/placeholder.svg?height=600&width=800"
                    alt="IQI Vietnam Real Estate"
                    width={800}
                    height={600}
                    className="rounded-lg shadow-2xl"
                  />
                </motion.div>
                <div className="absolute -top-4 -right-4 w-full h-full bg-gradient-to-r from-orange-200 to-orange-300 dark:from-orange-800 dark:to-orange-700 rounded-lg -z-10"></div>
              </div>
            </SlideIn>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { number: "15+", label: "Năm kinh nghiệm", icon: Award },
              { number: "10,000+", label: "Bất động sản đã bán", icon: TrendingUp },
              { number: "5,000+", label: "Khách hàng hài lòng", icon: Users },
              { number: "20+", label: "Văn phòng toàn quốc", icon: Globe },
            ].map((item, index) => (
              <ScaleIn key={index} delay={index * 0.2}>
                <motion.div whileHover={{ y: -5 }}>
                  <Card className="text-center border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                    <CardContent className="p-6">
                      <motion.div
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 0.6 }}
                        className="w-16 h-16 bg-gradient-to-r from-orange-100 to-orange-200 dark:from-orange-900/30 dark:to-orange-800/30 rounded-full flex items-center justify-center mx-auto mb-4"
                      >
                        <item.icon className="w-8 h-8 text-orange-600" />
                      </motion.div>
                      <div className="text-3xl font-bold text-orange-600 mb-2">{item.number}</div>
                      <div className="text-muted-foreground">{item.label}</div>
                    </CardContent>
                  </Card>
                </motion.div>
              </ScaleIn>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <FadeIn className="text-center mb-12">
            <Badge className="mb-4 bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300">
              DỊCH VỤ
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Dịch vụ của chúng tôi</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Chúng tôi cung cấp đầy đủ các dịch vụ bất động sản từ tư vấn, mua bán đến quản lý tài sản
            </p>
          </FadeIn>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Bất động sản Việt Nam",
                description: "Căn hộ, nhà phố, đất nền tại TP.HCM và Hà Nội với giá tốt nhất thị trường",
                icon: Building,
                href: "/products/vietnam",
                color: "orange",
              },
              {
                title: "Bất động sản Quốc tế",
                description: "Đầu tư bất động sản tại các quốc gia phát triển với lợi nhuận cao",
                icon: Globe,
                href: "/products/international",
                color: "blue",
              },
              {
                title: "Bất động sản Nghỉ dưỡng",
                description: "Resort, biệt thự biển, condotel tại các điểm du lịch nổi tiếng",
                icon: Palmtree,
                href: "/products/resort",
                color: "green",
              },
            ].map((service, index) => (
              <ScaleIn key={index} delay={index * 0.2}>
                <motion.div whileHover={{ y: -10 }}>
                  <Link href={service.href}>
                    <Card className="h-full hover:shadow-xl transition-all duration-300 group cursor-pointer border-0 shadow-lg">
                      <CardHeader>
                        <motion.div
                          whileHover={{ scale: 1.1 }}
                          className={`w-16 h-16 bg-gradient-to-r ${
                            service.color === "orange"
                              ? "from-orange-100 to-orange-200 dark:from-orange-900/30 dark:to-orange-800/30"
                              : service.color === "blue"
                                ? "from-blue-100 to-blue-200 dark:from-blue-900/30 dark:to-blue-800/30"
                                : "from-green-100 to-green-200 dark:from-green-900/30 dark:to-green-800/30"
                          } rounded-full flex items-center justify-center mb-4`}
                        >
                          <service.icon
                            className={`w-8 h-8 ${
                              service.color === "orange"
                                ? "text-orange-600"
                                : service.color === "blue"
                                  ? "text-blue-600"
                                  : "text-green-600"
                            }`}
                          />
                        </motion.div>
                        <CardTitle className="group-hover:text-orange-600 transition-colors">{service.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground mb-4">{service.description}</p>
                        <div className="flex items-center text-orange-600 group-hover:text-orange-700 transition-colors">
                          <span className="text-sm font-medium">Tìm hiểu thêm</span>
                          <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              </ScaleIn>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <FadeIn className="text-center mb-12">
            <Badge className="mb-4 bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300">
              DỰ ÁN NỔI BẬT
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Dự án được quan tâm nhất</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Những dự án bất động sản hot nhất hiện tại với tiềm năng tăng giá cao
            </p>
          </FadeIn>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Vinhomes Grand Park",
                location: "TP. Hồ Chí Minh",
                price: "2.5 - 4.2 tỷ",
                image: "/placeholder.svg?height=300&width=400",
                type: "Căn hộ",
                area: "50-80m²",
              },
              {
                title: "The Manor Central Park",
                location: "Hà Nội",
                price: "3.8 - 6.5 tỷ",
                image: "/placeholder.svg?height=300&width=400",
                type: "Căn hộ",
                area: "70-120m²",
              },
              {
                title: "Fusion Resort Phu Quoc",
                location: "Phú Quốc",
                price: "8.5 - 15 tỷ",
                image: "/placeholder.svg?height=300&width=400",
                type: "Resort Villa",
                area: "150-300m²",
              },
            ].map((property, index) => (
              <ScaleIn key={index} delay={index * 0.2}>
                <motion.div whileHover={{ y: -5 }}>
                  <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 group border-0 shadow-lg">
                    <div className="relative overflow-hidden">
                      <motion.div whileHover={{ scale: 1.05 }}>
                        <Image
                          src={property.image || "/placeholder.svg"}
                          alt={property.title}
                          width={400}
                          height={300}
                          className="w-full h-48 object-cover transition-transform duration-300"
                        />
                      </motion.div>
                      <div className="absolute top-4 left-4">
                        <Badge className="bg-orange-500 text-white">{property.type}</Badge>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <h3 className="font-bold text-lg mb-2 group-hover:text-orange-600 transition-colors">
                        {property.title}
                      </h3>
                      <div className="flex items-center text-muted-foreground mb-2">
                        <MapPin className="w-4 h-4 mr-1" />
                        <span className="text-sm">{property.location}</span>
                      </div>
                      <div className="flex justify-between items-center mb-4">
                        <span className="text-sm text-muted-foreground">Diện tích: {property.area}</span>
                        <span className="font-bold text-orange-600">{property.price}</span>
                      </div>
                      <Button className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700">
                        Xem chi tiết
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              </ScaleIn>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <FadeIn className="text-center mb-12">
            <Badge className="mb-4 bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300">
              ĐÁNH GIÁ
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Khách hàng nói gì về chúng tôi</h2>
          </FadeIn>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Anh Minh Tuấn",
                role: "Doanh nhân",
                content:
                  "IQI Vietnam đã giúp tôi tìm được căn hộ ưng ý tại Vinhomes. Dịch vụ chuyên nghiệp, tư vấn tận tình.",
                rating: 5,
              },
              {
                name: "Chị Lan Anh",
                role: "Giám đốc Marketing",
                content: "Đầu tư bất động sản quốc tế cùng IQI rất an tâm. Thủ tục nhanh chóng, minh bạch.",
                rating: 5,
              },
              {
                name: "Anh Đức Thành",
                role: "Kỹ sư",
                content: "Mua villa nghỉ dưỡng tại Phú Quốc thông qua IQI. Giá tốt, pháp lý rõ ràng.",
                rating: 5,
              },
            ].map((testimonial, index) => (
              <ScaleIn key={index} delay={index * 0.2}>
                <motion.div whileHover={{ y: -5 }}>
                  <Card className="h-full border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                    <CardContent className="p-6">
                      <div className="flex mb-4">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                        ))}
                      </div>
                      <p className="text-muted-foreground mb-4 italic">"{testimonial.content}"</p>
                      <div>
                        <div className="font-semibold">{testimonial.name}</div>
                        <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </ScaleIn>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-orange-600 to-orange-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <FadeIn>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Sẵn sàng đầu tư bất động sản?</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
              Liên hệ với chúng tôi ngay hôm nay để được tư vấn miễn phí và tìm hiểu những cơ hội đầu tư tốt nhất
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Link href="/consultation">
                  <Button size="lg" className="bg-white text-orange-600 hover:bg-gray-100">
                    Đặt lịch tư vấn
                  </Button>
                </Link>
              </motion.div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Link href="/contact">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-white text-white hover:bg-white hover:text-orange-600 bg-transparent"
                  >
                    Liên hệ ngay
                  </Button>
                </Link>
              </motion.div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">IQI</span>
                </div>
                <span className="font-bold text-xl">IQI Vietnam</span>
              </div>
              <p className="text-gray-400 mb-4">Đối tác tin cậy trong lĩnh vực bất động sản tại Việt Nam và quốc tế.</p>
              <div className="space-y-2">
                <div className="flex items-center">
                  <Phone className="w-4 h-4 mr-2 text-orange-500" />
                  <span className="text-sm">1900 1234</span>
                </div>
                <div className="flex items-center">
                  <Mail className="w-4 h-4 mr-2 text-orange-500" />
                  <span className="text-sm">info@iqivietnam.com</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2 text-orange-500" />
                  <span className="text-sm">TP. Hồ Chí Minh</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Sản phẩm</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link href="/products/vietnam" className="hover:text-orange-500 transition-colors">
                    Bất động sản Việt Nam
                  </Link>
                </li>
                <li>
                  <Link href="/products/international" className="hover:text-orange-500 transition-colors">
                    Bất động sản Quốc tế
                  </Link>
                </li>
                <li>
                  <Link href="/products/resort" className="hover:text-orange-500 transition-colors">
                    Bất động sản Nghỉ dưỡng
                  </Link>
                </li>
                <li>
                  <Link href="/partners" className="hover:text-orange-500 transition-colors">
                    Đối tác
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Công ty</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-orange-500 transition-colors">
                    Về chúng tôi
                  </Link>
                </li>
                <li>
                  <Link href="/about/history" className="hover:text-orange-500 transition-colors">
                    Lịch sử phát triển
                  </Link>
                </li>
                <li>
                  <Link href="/team" className="hover:text-orange-500 transition-colors">
                    Đội ngũ
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="hover:text-orange-500 transition-colors">
                    Tuyển dụng
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Hỗ trợ</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link href="/contact" className="hover:text-orange-500 transition-colors">
                    Liên hệ
                  </Link>
                </li>
                <li>
                  <Link href="/consultation" className="hover:text-orange-500 transition-colors">
                    Tư vấn miễn phí
                  </Link>
                </li>
                <li>
                  <Link href="/news" className="hover:text-orange-500 transition-colors">
                    Tin tức
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 IQI Vietnam. Tất cả quyền được bảo lưu.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
