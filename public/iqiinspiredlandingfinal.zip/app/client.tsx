"use client"

import type React from "react"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu"
import { cn } from "@/lib/utils"
import { Phone, Mail, MapPin, Facebook, Instagram, Linkedin, Youtube } from "lucide-react"

const inter = Inter({ subsets: ["latin"] })

const navigationItems = [
  {
    title: "BDS Quốc tế",
    href: "/products/international",
    description: "Bất động sản cao cấp tại các quốc gia Đông Nam Á",
  },
  {
    title: "BDS Việt Nam",
    href: "/products/vietnam",
    description: "Dự án bất động sản hàng đầu tại Việt Nam",
  },
  {
    title: "BDS nghỉ dưỡng",
    href: "/products/resort",
    description: "Resort và villa nghỉ dưỡng cao cấp",
  },
  {
    title: "Đối tác",
    href: "/partners",
    description: "Mạng lưới đối tác chiến lược toàn cầu",
  },
]

export default function ClientLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="vi" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          {/* Header */}
          <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <div className="container mx-auto px-4">
              <div className="flex h-16 items-center justify-between">
                <Link href="/" className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-sm">IQI</span>
                  </div>
                  <span className="font-bold text-xl">IQI Inspired</span>
                </Link>

                <NavigationMenu className="hidden md:flex">
                  <NavigationMenuList>
                    {navigationItems.map((item) => (
                      <NavigationMenuItem key={item.href}>
                        <NavigationMenuTrigger className="group relative">
                          <Link href={item.href} className="flex items-center">
                            {item.title}
                          </Link>
                          <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-600 to-purple-600 transition-all duration-300 group-hover:w-full"></span>
                        </NavigationMenuTrigger>
                        <NavigationMenuContent>
                          <div className="grid gap-3 p-6 w-[400px]">
                            <NavigationMenuLink asChild>
                              <Link
                                href={item.href}
                                className={cn(
                                  "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                                )}
                              >
                                <div className="text-sm font-medium leading-none">{item.title}</div>
                                <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                  {item.description}
                                </p>
                              </Link>
                            </NavigationMenuLink>
                          </div>
                        </NavigationMenuContent>
                      </NavigationMenuItem>
                    ))}

                    <NavigationMenuItem>
                      <NavigationMenuTrigger className="group relative">
                        Về chúng tôi
                        <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-600 to-purple-600 transition-all duration-300 group-hover:w-full"></span>
                      </NavigationMenuTrigger>
                      <NavigationMenuContent>
                        <div className="grid gap-3 p-6 w-[400px]">
                          <NavigationMenuLink asChild>
                            <Link
                              href="/about"
                              className={cn(
                                "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                              )}
                            >
                              <div className="text-sm font-medium leading-none">Giới thiệu</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                Tìm hiểu về IQI Inspired và sứ mệnh của chúng tôi
                              </p>
                            </Link>
                          </NavigationMenuLink>
                          <NavigationMenuLink asChild>
                            <Link
                              href="/team"
                              className={cn(
                                "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                              )}
                            >
                              <div className="text-sm font-medium leading-none">Đội ngũ</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                Gặp gỡ đội ngũ chuyên gia của chúng tôi
                              </p>
                            </Link>
                          </NavigationMenuLink>
                          <NavigationMenuLink asChild>
                            <Link
                              href="/careers"
                              className={cn(
                                "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                              )}
                            >
                              <div className="text-sm font-medium leading-none">Tuyển dụng</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                Cơ hội nghề nghiệp tại IQI Inspired
                              </p>
                            </Link>
                          </NavigationMenuLink>
                        </div>
                      </NavigationMenuContent>
                    </NavigationMenuItem>

                    <NavigationMenuItem>
                      <NavigationMenuTrigger className="group relative">
                        Dịch vụ
                        <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-600 to-purple-600 transition-all duration-300 group-hover:w-full"></span>
                      </NavigationMenuTrigger>
                      <NavigationMenuContent>
                        <div className="grid gap-3 p-6 w-[400px]">
                          <NavigationMenuLink asChild>
                            <Link
                              href="/consultation"
                              className={cn(
                                "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                              )}
                            >
                              <div className="text-sm font-medium leading-none">Tư vấn đầu tư</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                Tư vấn chuyên sâu về đầu tư bất động sản
                              </p>
                            </Link>
                          </NavigationMenuLink>
                          <NavigationMenuLink asChild>
                            <Link
                              href="/contact"
                              className={cn(
                                "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                              )}
                            >
                              <div className="text-sm font-medium leading-none">Liên hệ</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                Liên hệ với đội ngũ chuyên gia của chúng tôi
                              </p>
                            </Link>
                          </NavigationMenuLink>
                          <NavigationMenuLink asChild>
                            <Link
                              href="/news"
                              className={cn(
                                "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                              )}
                            >
                              <div className="text-sm font-medium leading-none">Tin tức</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                Cập nhật tin tức thị trường bất động sản
                              </p>
                            </Link>
                          </NavigationMenuLink>
                        </div>
                      </NavigationMenuContent>
                    </NavigationMenuItem>
                  </NavigationMenuList>
                </NavigationMenu>

                <div className="flex items-center space-x-4">
                  <ThemeToggle />
                  <Button asChild className="hidden md:inline-flex">
                    <Link href="/contact">Liên hệ tư vấn</Link>
                  </Button>
                </div>
              </div>
            </div>
          </header>

          <main>{children}</main>

          {/* Footer */}
          <footer className="bg-gray-900 text-white">
            <div className="container mx-auto px-4 py-12">
              <div className="grid md:grid-cols-4 gap-8">
                <div>
                  <div className="flex items-center space-x-2 mb-4">
                    <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                      <span className="text-white font-bold text-sm">IQI</span>
                    </div>
                    <span className="font-bold text-xl">IQI Inspired</span>
                  </div>
                  <p className="text-gray-400 mb-4">
                    Chuyên gia tư vấn bất động sản hàng đầu với mạng lưới toàn cầu và dịch vụ chuyên nghiệp.
                  </p>
                  <div className="flex space-x-4">
                    <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                      <Facebook className="w-5 h-5" />
                    </Link>
                    <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                      <Instagram className="w-5 h-5" />
                    </Link>
                    <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                      <Linkedin className="w-5 h-5" />
                    </Link>
                    <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                      <Youtube className="w-5 h-5" />
                    </Link>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-4">Sản phẩm</h3>
                  <ul className="space-y-2">
                    <li>
                      <Link href="/products/international" className="text-gray-400 hover:text-white transition-colors">
                        BDS Quốc tế
                      </Link>
                    </li>
                    <li>
                      <Link href="/products/vietnam" className="text-gray-400 hover:text-white transition-colors">
                        BDS Việt Nam
                      </Link>
                    </li>
                    <li>
                      <Link href="/products/resort" className="text-gray-400 hover:text-white transition-colors">
                        BDS nghỉ dưỡng
                      </Link>
                    </li>
                    <li>
                      <Link href="/partners" className="text-gray-400 hover:text-white transition-colors">
                        Đối tác
                      </Link>
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-4">Công ty</h3>
                  <ul className="space-y-2">
                    <li>
                      <Link href="/about" className="text-gray-400 hover:text-white transition-colors">
                        Giới thiệu
                      </Link>
                    </li>
                    <li>
                      <Link href="/team" className="text-gray-400 hover:text-white transition-colors">
                        Đội ngũ
                      </Link>
                    </li>
                    <li>
                      <Link href="/careers" className="text-gray-400 hover:text-white transition-colors">
                        Tuyển dụng
                      </Link>
                    </li>
                    <li>
                      <Link href="/news" className="text-gray-400 hover:text-white transition-colors">
                        Tin tức
                      </Link>
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-4">Liên hệ</h3>
                  <ul className="space-y-2">
                    <li className="flex items-center text-gray-400">
                      <Phone className="w-4 h-4 mr-2" />
                      +84 901 234 567
                    </li>
                    <li className="flex items-center text-gray-400">
                      <Mail className="w-4 h-4 mr-2" />
                      info@iqiinspired.com
                    </li>
                    <li className="flex items-start text-gray-400">
                      <MapPin className="w-4 h-4 mr-2 mt-1" />
                      <span>
                        Tầng 15, Tòa nhà ABC
                        <br />
                        123 Nguyễn Huệ, Q.1
                        <br />
                        TP.HCM, Việt Nam
                      </span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
                <p>&copy; 2024 IQI Inspired. Tất cả quyền được bảo lưu.</p>
              </div>
            </div>
          </footer>

          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}
