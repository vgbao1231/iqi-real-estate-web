"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FadeIn, SlideIn } from "@/components/animations"
import {
  ArrowLeft,
  MapPin,
  Star,
  Calendar,
  Building,
  Waves,
  Phone,
  Mail,
  Share2,
  Heart,
  Bed,
  Bath,
  Square,
  Car,
  Wifi,
  Utensils,
  Dumbbell,
  TreePine,
  Camera,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { useState } from "react"

export default function ResortDetailPage({ params }: { params: { id: string } }) {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0)
  const [showContactForm, setShowContactForm] = useState(false)

  // Mock data - trong thực tế sẽ fetch từ API dựa trên params.id
  const property = {
    id: 1,
    name: "InterContinental Phu Quoc",
    location: "Phú Quốc, Kiên Giang",
    address: "Bãi Dài, Gành Dầu, Phú Quốc, Kiên Giang",
    type: "Resort Villa",
    price: "Từ 8.5 tỷ",
    pricePerSqm: "70 triệu/m²",
    bedrooms: "2-4 phòng ngủ",
    bathrooms: "2-4 phòng tắm",
    area: "120-300 m²",
    status: "Đang bán",
    completion: "Q2/2025",
    developer: "Sun Group",
    rating: 4.8,
    reviews: 156,
    images: [
      "/placeholder.svg?height=600&width=800",
      "/placeholder.svg?height=600&width=800",
      "/placeholder.svg?height=600&width=800",
      "/placeholder.svg?height=600&width=800",
      "/placeholder.svg?height=600&width=800",
      "/placeholder.svg?height=600&width=800",
    ],
    description:
      "InterContinental Phu Quoc là khu nghỉ dưỡng cao cấp nằm trên bãi biển Bãi Dài tuyệt đẹp, mang đến trải nghiệm nghỉ dưỡng đẳng cấp quốc tế với thiết kế hiện đại hòa quyện cùng thiên nhiên nhiệt đới.",
    features: [
      "Bãi biển riêng 500m",
      "Golf course 18 lỗ",
      "Spa cao cấp InterContinental",
      "Marina riêng",
      "5 nhà hàng & bar",
      "Kids club",
      "Fitness center",
      "Tennis court",
      "Water sports center",
      "Concierge 24/7",
    ],
    amenities: [
      { icon: Waves, name: "Bãi biển riêng", description: "500m bãi biển riêng tư" },
      { icon: TreePine, name: "Golf course", description: "Sân golf 18 lỗ championship" },
      { icon: Dumbbell, name: "Spa & Fitness", description: "Spa cao cấp và phòng gym hiện đại" },
      { icon: Utensils, name: "Dining", description: "5 nhà hàng và bar đẳng cấp" },
      { icon: Car, name: "Valet parking", description: "Dịch vụ đỗ xe cao cấp" },
      { icon: Wifi, name: "WiFi miễn phí", description: "Internet tốc độ cao toàn khu" },
    ],
    floorPlans: [
      {
        name: "Villa 2 phòng ngủ",
        area: "120 m²",
        bedrooms: 2,
        bathrooms: 2,
        price: "8.5 tỷ",
        image: "/placeholder.svg?height=400&width=600",
      },
      {
        name: "Villa 3 phòng ngủ",
        area: "200 m²",
        bedrooms: 3,
        bathrooms: 3,
        price: "12.8 tỷ",
        image: "/placeholder.svg?height=400&width=600",
      },
      {
        name: "Villa 4 phòng ngủ",
        area: "300 m²",
        bedrooms: 4,
        bathrooms: 4,
        price: "18.5 tỷ",
        image: "/placeholder.svg?height=400&width=600",
      },
    ],
    agent: {
      name: "Nguyễn Thị Mai Anh",
      title: "Chuyên viên tư vấn Resort",
      phone: "0901 234 567",
      email: "maianh.nguyen@iqi.com",
      avatar: "/placeholder.svg?height=80&width=80",
      experience: "8 năm kinh nghiệm",
      specialization: "Bất động sản nghỉ dưỡng",
    },
    nearbyAttractions: [
      { name: "Cáp treo Hòn Thơm", distance: "2.5 km", type: "Điểm tham quan" },
      { name: "Vinpearl Safari", distance: "5 km", type: "Công viên giải trí" },
      { name: "Chợ đêm Dinh Cậu", distance: "15 km", type: "Mua sắm" },
      { name: "Sân bay Phú Quốc", distance: "25 km", type: "Giao thông" },
    ],
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="py-6 border-b">
        <div className="container mx-auto px-4">
          <FadeIn>
            <Link href="/products/resort" className="inline-flex items-center text-green-600 hover:text-green-700 mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Quay lại danh sách resort
            </Link>
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
                    {property.type}
                  </Badge>
                  <Badge variant={property.status === "Đang bán" ? "default" : "secondary"}>{property.status}</Badge>
                </div>
                <h1 className="text-3xl md:text-4xl font-bold mb-2">{property.name}</h1>
                <p className="text-muted-foreground flex items-center">
                  <MapPin className="w-4 h-4 mr-1" />
                  {property.address}
                </p>
                <div className="flex items-center gap-4 mt-2">
                  <div className="flex items-center">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                    <span className="font-medium">{property.rating}</span>
                    <span className="text-muted-foreground ml-1">({property.reviews} đánh giá)</span>
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <Calendar className="w-4 h-4 mr-1" />
                    <span>Bàn giao: {property.completion}</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-green-600 mb-1">{property.price}</div>
                <div className="text-muted-foreground">{property.pricePerSqm}</div>
                <div className="flex gap-2 mt-4">
                  <Button variant="outline" size="sm">
                    <Heart className="w-4 h-4 mr-2" />
                    Yêu thích
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share2 className="w-4 h-4 mr-2" />
                    Chia sẻ
                  </Button>
                </div>
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Image Gallery */}
            <FadeIn>
              <Card className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="relative">
                    <Image
                      src={property.images[selectedImageIndex] || "/placeholder.svg"}
                      alt={property.name}
                      width={800}
                      height={600}
                      className="w-full h-96 object-cover"
                    />
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-black/70 text-white">
                        <Camera className="w-3 h-3 mr-1" />
                        {selectedImageIndex + 1}/{property.images.length}
                      </Badge>
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="grid grid-cols-6 gap-2">
                      {property.images.map((image, index) => (
                        <motion.div
                          key={index}
                          whileHover={{ scale: 1.05 }}
                          className={`cursor-pointer rounded-lg overflow-hidden border-2 ${
                            selectedImageIndex === index ? "border-green-500" : "border-transparent"
                          }`}
                          onClick={() => setSelectedImageIndex(index)}
                        >
                          <Image
                            src={image || "/placeholder.svg"}
                            alt={`${property.name} ${index + 1}`}
                            width={100}
                            height={80}
                            className="w-full h-16 object-cover"
                          />
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </FadeIn>

            {/* Property Details Tabs */}
            <FadeIn delay={0.2}>
              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="overview">Tổng quan</TabsTrigger>
                  <TabsTrigger value="amenities">Tiện ích</TabsTrigger>
                  <TabsTrigger value="floorplans">Mặt bằng</TabsTrigger>
                  <TabsTrigger value="location">Vị trí</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Mô tả dự án</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <p className="text-muted-foreground leading-relaxed">{property.description}</p>

                      <div className="grid md:grid-cols-4 gap-6">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-lg">
                            <Bed className="w-5 h-5 text-green-600" />
                          </div>
                          <div>
                            <div className="font-semibold">{property.bedrooms}</div>
                            <div className="text-sm text-muted-foreground">Phòng ngủ</div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                            <Bath className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <div className="font-semibold">{property.bathrooms}</div>
                            <div className="text-sm text-muted-foreground">Phòng tắm</div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-lg">
                            <Square className="w-5 h-5 text-orange-600" />
                          </div>
                          <div>
                            <div className="font-semibold">{property.area}</div>
                            <div className="text-sm text-muted-foreground">Diện tích</div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
                            <Building className="w-5 h-5 text-purple-600" />
                          </div>
                          <div>
                            <div className="font-semibold">{property.developer}</div>
                            <div className="text-sm text-muted-foreground">Chủ đầu tư</div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="font-semibold mb-3">Đặc điểm nổi bật</h3>
                        <div className="grid md:grid-cols-2 gap-2">
                          {property.features.map((feature, index) => (
                            <div key={index} className="flex items-center text-sm">
                              <Waves className="w-4 h-4 mr-2 text-green-600 flex-shrink-0" />
                              {feature}
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="amenities" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Tiện ích resort</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-2 gap-6">
                        {property.amenities.map((amenity, index) => (
                          <div key={index} className="flex items-start space-x-4">
                            <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-lg">
                              <amenity.icon className="w-6 h-6 text-green-600" />
                            </div>
                            <div>
                              <h4 className="font-semibold mb-1">{amenity.name}</h4>
                              <p className="text-sm text-muted-foreground">{amenity.description}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="floorplans" className="mt-6">
                  <div className="space-y-6">
                    {property.floorPlans.map((plan, index) => (
                      <Card key={index}>
                        <CardContent className="p-6">
                          <div className="grid md:grid-cols-2 gap-6">
                            <div>
                              <Image
                                src={plan.image || "/placeholder.svg"}
                                alt={plan.name}
                                width={600}
                                height={400}
                                className="w-full h-64 object-cover rounded-lg"
                              />
                            </div>
                            <div className="space-y-4">
                              <div>
                                <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
                                <div className="text-2xl font-bold text-green-600">{plan.price}</div>
                              </div>
                              <div className="grid grid-cols-3 gap-4">
                                <div className="text-center">
                                  <div className="font-semibold">{plan.bedrooms}</div>
                                  <div className="text-sm text-muted-foreground">Phòng ngủ</div>
                                </div>
                                <div className="text-center">
                                  <div className="font-semibold">{plan.bathrooms}</div>
                                  <div className="text-sm text-muted-foreground">Phòng tắm</div>
                                </div>
                                <div className="text-center">
                                  <div className="font-semibold">{plan.area}</div>
                                  <div className="text-sm text-muted-foreground">Diện tích</div>
                                </div>
                              </div>
                              <Button className="w-full bg-green-600 hover:bg-green-700">Tư vấn mặt bằng này</Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="location" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Vị trí & Tiện ích xung quanh</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                        <p className="text-muted-foreground">Bản đồ Google Maps sẽ được tích hợp tại đây</p>
                      </div>

                      <div>
                        <h3 className="font-semibold mb-4">Điểm đến gần đây</h3>
                        <div className="grid md:grid-cols-2 gap-4">
                          {property.nearbyAttractions.map((attraction, index) => (
                            <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                              <div>
                                <div className="font-medium">{attraction.name}</div>
                                <div className="text-sm text-muted-foreground">{attraction.type}</div>
                              </div>
                              <div className="text-sm font-medium text-green-600">{attraction.distance}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </FadeIn>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Agent Card */}
            <SlideIn direction="right">
              <Card className="sticky top-8">
                <CardHeader>
                  <CardTitle>Liên hệ tư vấn</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <Image
                      src={property.agent.avatar || "/placeholder.svg"}
                      alt={property.agent.name}
                      width={80}
                      height={80}
                      className="rounded-full"
                    />
                    <div>
                      <h3 className="font-semibold">{property.agent.name}</h3>
                      <p className="text-sm text-muted-foreground">{property.agent.title}</p>
                      <p className="text-xs text-muted-foreground">{property.agent.experience}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Button className="w-full bg-green-600 hover:bg-green-700">
                      <Phone className="w-4 h-4 mr-2" />
                      {property.agent.phone}
                    </Button>
                    <Button variant="outline" className="w-full bg-transparent">
                      <Mail className="w-4 h-4 mr-2" />
                      Gửi email
                    </Button>
                  </div>

                  <div className="pt-4 border-t">
                    <Button
                      variant="outline"
                      className="w-full bg-transparent"
                      onClick={() => setShowContactForm(!showContactForm)}
                    >
                      Đặt lịch xem dự án
                    </Button>
                  </div>

                  {showContactForm && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="space-y-3 pt-4 border-t"
                    >
                      <input
                        type="text"
                        placeholder="Họ và tên"
                        className="w-full p-3 border border-input rounded-md bg-background"
                      />
                      <input
                        type="email"
                        placeholder="Email"
                        className="w-full p-3 border border-input rounded-md bg-background"
                      />
                      <input
                        type="tel"
                        placeholder="Số điện thoại"
                        className="w-full p-3 border border-input rounded-md bg-background"
                      />
                      <textarea
                        placeholder="Tin nhắn của bạn..."
                        rows={3}
                        className="w-full p-3 border border-input rounded-md bg-background resize-none"
                      />
                      <Button className="w-full bg-green-600 hover:bg-green-700">Gửi yêu cầu</Button>
                    </motion.div>
                  )}
                </CardContent>
              </Card>
            </SlideIn>

            {/* Quick Info */}
            <SlideIn direction="right" delay={0.2}>
              <Card>
                <CardHeader>
                  <CardTitle>Thông tin nhanh</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Loại hình:</span>
                    <span className="font-medium">{property.type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Chủ đầu tư:</span>
                    <span className="font-medium">{property.developer}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Trạng thái:</span>
                    <Badge variant={property.status === "Đang bán" ? "default" : "secondary"}>{property.status}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Bàn giao:</span>
                    <span className="font-medium">{property.completion}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Đánh giá:</span>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                      <span className="font-medium">{property.rating}/5</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </SlideIn>
          </div>
        </div>
      </div>
    </div>
  )
}
