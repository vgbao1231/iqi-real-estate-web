"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FadeIn, ScaleIn } from "@/components/animations"
import {
  ArrowLeft,
  MapPin,
  Waves,
  Search,
  Filter,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Building,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { useState, useMemo } from "react"

export default function ResortPropertiesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCountry, setSelectedCountry] = useState("all")
  const [selectedPriceRange, setPriceRange] = useState("all")
  const [selectedType, setSelectedType] = useState("all")
  const [currentPage, setCurrentPage] = useState(1)
  const [showFilters, setShowFilters] = useState(false)
  const itemsPerPage = 9

  const resortProperties = [
    {
      id: 1,
      name: "InterContinental Phu Quoc",
      location: "Phú Quốc, Kiên Giang",
      country: "vietnam",
      type: "Resort Villa",
      price: "Từ 8.5 tỷ",
      priceValue: 8500000000,
      bedrooms: "2-4 phòng ngủ",
      area: "120-300 m²",
      features: ["Bãi biển riêng", "Golf course", "Spa cao cấp", "Marina"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Đang bán",
      completion: "Q2/2025",
      developer: "Sun Group",
      description: "Resort villa cao cấp với bãi biển riêng và tiện ích 5 sao tại đảo ngọc Phú Quốc.",
    },
    {
      id: 2,
      name: "Fusion Resort Cam Ranh",
      location: "Cam Ranh, Khánh Hòa",
      country: "vietnam",
      type: "Beachfront Villa",
      price: "Từ 6.2 tỷ",
      priceValue: 6200000000,
      bedrooms: "1-3 phòng ngủ",
      area: "80-200 m²",
      features: ["All-inclusive", "Spa trị liệu", "Nhà hàng 5 sao", "Kids club"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Sắp mở bán",
      completion: "Q4/2024",
      developer: "Fusion Group",
      description: "Villa nghỉ dưỡng bên bờ biển với dịch vụ all-inclusive độc đáo.",
    },
    {
      id: 3,
      name: "JW Marriott Phu Quoc",
      location: "Phú Quốc, Kiên Giang",
      country: "vietnam",
      type: "Luxury Condotel",
      price: "Từ 4.8 tỷ",
      priceValue: 4800000000,
      bedrooms: "Studio-2 phòng ngủ",
      area: "45-120 m²",
      features: ["Quản lý Marriott", "Hồ bơi vô cực", "Spa JW", "Beach club"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Đang bán",
      completion: "Q1/2025",
      developer: "BIM Group",
      description: "Condotel hạng sang được quản lý bởi thương hiệu Marriott danh tiếng.",
    },
    {
      id: 4,
      name: "Bali Mandira Beach Resort",
      location: "Legian, Bali",
      country: "indonesia",
      type: "Beachfront Suite",
      price: "Từ $450,000",
      priceValue: 450000,
      bedrooms: "1-2 phòng ngủ",
      area: "60-140 m²",
      features: ["Bãi biển Legian", "Tropical garden", "Balinese spa", "Rooftop bar"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Đang bán",
      completion: "Q3/2024",
      developer: "Mandira Group",
      description: "Suite nghỉ dưỡng bên bãi biển Legian nổi tiếng với phong cách Bali truyền thống.",
    },
    {
      id: 5,
      name: "Phuket Oceanfront Villas",
      location: "Patong, Phuket",
      country: "thailand",
      type: "Sea View Villa",
      price: "Từ $680,000",
      priceValue: 680000,
      bedrooms: "2-4 phòng ngủ",
      area: "150-350 m²",
      features: ["Private pool", "Sea view", "Thai spa", "Concierge"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Sắp bàn giao",
      completion: "Q2/2024",
      developer: "Oceanfront Development",
      description: "Villa mặt biển với hồ bơi riêng và tầm nhìn tuyệt đẹp ra đại dương.",
    },
    {
      id: 6,
      name: "Langkawi Luxury Resort",
      location: "Langkawi, Malaysia",
      country: "malaysia",
      type: "Rainforest Villa",
      price: "Từ $380,000",
      priceValue: 380000,
      bedrooms: "1-3 phòng ngủ",
      area: "80-200 m²",
      features: ["Rainforest view", "Cable car", "Duty-free shopping", "Marina"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Đang bán",
      completion: "Q1/2025",
      developer: "Langkawi Development",
      description: "Villa nghỉ dưỡng giữa rừng nhiệt đới với thiên nhiên hoang sơ.",
    },
    {
      id: 7,
      name: "Bintan Resort Villas",
      location: "Bintan, Indonesia",
      country: "indonesia",
      type: "Beach Villa",
      price: "Từ $320,000",
      priceValue: 320000,
      bedrooms: "2-3 phòng ngủ",
      area: "100-180 m²",
      features: ["Private beach", "Golf course", "Water sports", "Spa retreat"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Đang bán",
      completion: "Q4/2024",
      developer: "Bintan Resorts",
      description: "Villa bãi biển riêng tư với sân golf và các hoạt động thể thao nước.",
    },
    {
      id: 8,
      name: "Koh Samui Paradise Resort",
      location: "Koh Samui, Thailand",
      country: "thailand",
      type: "Tropical Villa",
      price: "Từ $550,000",
      priceValue: 550000,
      bedrooms: "2-4 phòng ngủ",
      area: "120-280 m²",
      features: ["Infinity pool", "Sunset view", "Thai massage", "Private chef"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Sắp mở bán",
      completion: "Q3/2025",
      developer: "Samui Paradise",
      description: "Villa nhiệt đới với hồ bơi vô cực và tầm nhìn hoàng hôn tuyệt đẹp.",
    },
    {
      id: 9,
      name: "Da Nang Beachfront Resort",
      location: "Đà Nẵng, Việt Nam",
      country: "vietnam",
      type: "Resort Apartment",
      price: "Từ 3.8 tỷ",
      priceValue: 3800000000,
      bedrooms: "1-3 phòng ngủ",
      area: "55-130 m²",
      features: ["Bãi biển Mỹ Khê", "Spa & wellness", "Multiple pools", "Kids club"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Đang bán",
      completion: "Q1/2024",
      developer: "Da Nang Resort Group",
      description: "Căn hộ resort bên bãi biển Mỹ Khê với tiện ích nghỉ dưỡng đầy đủ.",
    },
    {
      id: 10,
      name: "Boracay Beach Suites",
      location: "Boracay, Philippines",
      country: "philippines",
      type: "Beach Suite",
      price: "Từ $420,000",
      priceValue: 420000,
      bedrooms: "1-2 phòng ngủ",
      area: "70-120 m²",
      features: ["White Beach access", "Island hopping", "Water activities", "Sunset bar"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Đang bán",
      completion: "Q2/2025",
      developer: "Boracay Resorts",
      description: "Suite nghỉ dưỡng với quyền truy cập bãi biển trắng nổi tiếng thế giới.",
    },
    {
      id: 11,
      name: "Nha Trang Bay Resort",
      location: "Nha Trang, Khánh Hòa",
      country: "vietnam",
      type: "Bay View Villa",
      price: "Từ 5.2 tỷ",
      priceValue: 5200000000,
      bedrooms: "2-3 phòng ngủ",
      area: "90-160 m²",
      features: ["Nha Trang Bay view", "Private balcony", "Resort amenities", "Diving center"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Sắp bàn giao",
      completion: "Q3/2024",
      developer: "Nha Trang Bay Development",
      description: "Villa với tầm nhìn ra vịnh Nha Trang và trung tâm lặn biển chuyên nghiệp.",
    },
    {
      id: 12,
      name: "Cebu Resort Residences",
      location: "Cebu, Philippines",
      country: "philippines",
      type: "Resort Residence",
      price: "Từ $380,000",
      priceValue: 380000,
      bedrooms: "1-3 phòng ngủ",
      area: "65-150 m²",
      features: ["Mountain & sea view", "Resort facilities", "Golf nearby", "Cultural tours"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Đang bán",
      completion: "Q4/2024",
      developer: "Cebu Resort Group",
      description: "Căn hộ resort với tầm nhìn núi và biển, gần sân golf và các tour văn hóa.",
    },
  ]

  const countries = [
    { value: "all", label: "Tất cả quốc gia" },
    { value: "vietnam", label: "Việt Nam" },
    { value: "thailand", label: "Thái Lan" },
    { value: "indonesia", label: "Indonesia" },
    { value: "malaysia", label: "Malaysia" },
    { value: "philippines", label: "Philippines" },
  ]

  const priceRanges = [
    { value: "all", label: "Tất cả mức giá" },
    { value: "under5", label: "Dưới 5 tỷ / $500K" },
    { value: "5to10", label: "5-10 tỷ / $500K-1M" },
    { value: "above10", label: "Trên 10 tỷ / $1M+" },
  ]

  const propertyTypes = [
    { value: "all", label: "Tất cả loại hình" },
    { value: "villa", label: "Villa" },
    { value: "suite", label: "Suite" },
    { value: "condotel", label: "Condotel" },
    { value: "apartment", label: "Apartment" },
  ]

  // Filter logic
  const filteredProperties = useMemo(() => {
    return resortProperties.filter((property) => {
      const matchesSearch =
        property.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        property.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        property.developer.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesCountry = selectedCountry === "all" || property.country === selectedCountry

      const matchesPrice =
        selectedPriceRange === "all" ||
        (() => {
          if (property.country === "vietnam") {
            switch (selectedPriceRange) {
              case "under5":
                return property.priceValue < 5000000000
              case "5to10":
                return property.priceValue >= 5000000000 && property.priceValue < 10000000000
              case "above10":
                return property.priceValue >= 10000000000
              default:
                return true
            }
          } else {
            switch (selectedPriceRange) {
              case "under5":
                return property.priceValue < 500000
              case "5to10":
                return property.priceValue >= 500000 && property.priceValue < 1000000
              case "above10":
                return property.priceValue >= 1000000
              default:
                return true
            }
          }
        })()

      const matchesType = selectedType === "all" || property.type.toLowerCase().includes(selectedType.toLowerCase())

      return matchesSearch && matchesCountry && matchesPrice && matchesType
    })
  }, [searchTerm, selectedCountry, selectedPriceRange, selectedType])

  // Pagination logic
  const totalPages = Math.ceil(filteredProperties.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedProperties = filteredProperties.slice(startIndex, startIndex + itemsPerPage)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="py-12 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-950/20 dark:to-blue-900/20">
        <div className="container mx-auto px-4">
          <FadeIn>
            <Link href="/" className="inline-flex items-center text-green-600 hover:text-green-700 mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Quay lại trang chủ
            </Link>
            <Badge className="mb-4 bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
              BẤT ĐỘNG SẢN NGHỈ DƯỠNG
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Bất động sản Nghỉ dưỡng</h1>
            <p className="text-xl text-muted-foreground max-w-3xl">
              Khám phá những resort và villa nghỉ dưỡng cao cấp tại các điểm đến hàng đầu Việt Nam và Đông Nam Á.
            </p>
          </FadeIn>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="py-8 bg-muted/30">
        <div className="container mx-auto px-4">
          <FadeIn>
            <div className="bg-white dark:bg-gray-900 rounded-lg p-6 shadow-sm">
              {/* Search Bar */}
              <div className="flex flex-col lg:flex-row gap-4 mb-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input
                      placeholder="Tìm kiếm theo tên dự án, vị trí, chủ đầu tư..."
                      className="pl-10"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="lg:w-auto">
                  <Filter className="w-4 h-4 mr-2" />
                  Bộ lọc
                  <ChevronDown className={`w-4 h-4 ml-2 transition-transform ${showFilters ? "rotate-180" : ""}`} />
                </Button>
              </div>

              {/* Filters */}
              {showFilters && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="grid md:grid-cols-3 gap-4 pt-4 border-t"
                >
                  <div>
                    <label className="text-sm font-medium mb-2 block">Quốc gia</label>
                    <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {countries.map((country) => (
                          <SelectItem key={country.value} value={country.value}>
                            {country.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Mức giá</label>
                    <Select value={selectedPriceRange} onValueChange={setPriceRange}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {priceRanges.map((range) => (
                          <SelectItem key={range.value} value={range.value}>
                            {range.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Loại hình</label>
                    <Select value={selectedType} onValueChange={setSelectedType}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {propertyTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </motion.div>
              )}

              {/* Results Summary */}
              <div className="flex items-center justify-between mt-4 pt-4 border-t text-sm text-muted-foreground">
                <span>
                  Hiển thị {startIndex + 1}-{Math.min(startIndex + itemsPerPage, filteredProperties.length)} trong tổng
                  số {filteredProperties.length} dự án
                </span>
                {(searchTerm ||
                  selectedCountry !== "all" ||
                  selectedPriceRange !== "all" ||
                  selectedType !== "all") && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setSearchTerm("")
                      setSelectedCountry("all")
                      setPriceRange("all")
                      setSelectedType("all")
                      setCurrentPage(1)
                    }}
                  >
                    Xóa bộ lọc
                  </Button>
                )}
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* Resort Properties */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {paginatedProperties.length > 0 ? (
            <>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                {paginatedProperties.map((property, index) => (
                  <ScaleIn key={property.id} delay={index * 0.1}>
                    <motion.div whileHover={{ y: -10 }}>
                      <Card className="overflow-hidden h-full">
                        <div className="relative">
                          <motion.div whileHover={{ scale: 1.1 }}>
                            <Image
                              src={property.image || "/placeholder.svg"}
                              alt={property.name}
                              width={400}
                              height={300}
                              className="w-full h-48 object-cover"
                            />
                          </motion.div>
                          <div className="absolute top-4 left-4">
                            <Badge className="bg-white/90 text-gray-900">{property.developer}</Badge>
                          </div>
                          <div className="absolute top-4 right-4">
                            <Badge
                              variant={property.status === "Đang bán" ? "default" : "secondary"}
                              className={property.status === "Đang bán" ? "bg-green-600" : ""}
                            >
                              {property.status}
                            </Badge>
                          </div>
                        </div>

                        <CardHeader>
                          <div className="flex justify-between items-start">
                            <div>
                              <CardTitle className="text-lg mb-2">{property.name}</CardTitle>
                              <p className="text-muted-foreground flex items-center text-sm">
                                <MapPin className="w-4 h-4 mr-1" />
                                {property.location}
                              </p>
                            </div>
                            <div className="text-right">
                              <div className="text-xl font-bold text-green-600">{property.price}</div>
                              <div className="text-xs text-muted-foreground">{property.type}</div>
                            </div>
                          </div>
                        </CardHeader>

                        <CardContent>
                          <div className="space-y-4">
                            <p className="text-sm text-muted-foreground line-clamp-2">{property.description}</p>

                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <span className="text-muted-foreground">Phòng ngủ:</span>
                                <div className="font-semibold">{property.bedrooms}</div>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Diện tích:</span>
                                <div className="font-semibold">{property.area}</div>
                              </div>
                            </div>

                            <div>
                              <h4 className="font-semibold mb-2 text-sm">Tiện ích resort:</h4>
                              <div className="grid grid-cols-1 gap-1">
                                {property.features.map((feature, idx) => (
                                  <div key={idx} className="flex items-center text-xs text-muted-foreground">
                                    <Waves className="w-3 h-3 mr-1 text-blue-600 flex-shrink-0" />
                                    {feature}
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="flex gap-2 pt-4">
                              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="flex-1">
                                <Link href={`/products/resort/${property.id}`}>
                                  <Button className="w-full bg-green-600 hover:bg-green-700 text-sm">
                                    Xem chi tiết
                                  </Button>
                                </Link>
                              </motion.div>
                              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                                <Button variant="outline" size="sm">
                                  Liên hệ
                                </Button>
                              </motion.div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  </ScaleIn>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <FadeIn>
                  <div className="flex items-center justify-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                    >
                      <ChevronLeft className="w-4 h-4" />
                      Trước
                    </Button>

                    <div className="flex space-x-1">
                      {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                        <Button
                          key={page}
                          variant={currentPage === page ? "default" : "outline"}
                          size="sm"
                          onClick={() => setCurrentPage(page)}
                          className="w-10"
                        >
                          {page}
                        </Button>
                      ))}
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                    >
                      Sau
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </FadeIn>
              )}
            </>
          ) : (
            <div className="text-center py-12">
              <Building className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Không tìm thấy dự án</h3>
              <p className="text-muted-foreground mb-4">Thử thay đổi bộ lọc hoặc từ khóa tìm kiếm</p>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("")
                  setSelectedCountry("all")
                  setPriceRange("all")
                  setSelectedType("all")
                  setCurrentPage(1)
                }}
              >
                Xóa bộ lọc
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-gradient-to-r from-green-600 to-blue-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <FadeIn>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Tìm hiểu thêm về dự án nghỉ dưỡng</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
              Liên hệ với chuyên gia để được tư vấn chi tiết về các dự án resort hàng đầu
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button size="lg" className="bg-white text-green-600 hover:bg-gray-100">
                  Tư vấn miễn phí ngay
                </Button>
              </motion.div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-green-600 bg-transparent"
                >
                  Tải brochure dự án
                </Button>
              </motion.div>
            </div>
          </FadeIn>
        </div>
      </section>
    </div>
  )
}
