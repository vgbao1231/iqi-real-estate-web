"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FadeIn, ScaleIn } from "@/components/animations"
import {
  ArrowLeft,
  MapPin,
  CheckCircle,
  Building,
  Search,
  Filter,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Bed,
  Bath,
  Square,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { useState, useMemo } from "react"

export default function VietnamPropertiesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCity, setSelectedCity] = useState("all")
  const [selectedDistrict, setSelectedDistrict] = useState("all")
  const [selectedPriceRange, setPriceRange] = useState("all")
  const [selectedType, setSelectedType] = useState("all")
  const [selectedBedrooms, setSelectedBedrooms] = useState("all")
  const [selectedBathrooms, setSelectedBathrooms] = useState("all")
  const [selectedArea, setSelectedArea] = useState("all")
  const [currentPage, setCurrentPage] = useState(1)
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false)
  const itemsPerPage = 9

  // All properties data
  const allProperties = [
    {
      id: 1,
      name: "Vinhomes Grand Park",
      location: "Quận 9, TP.HCM",
      city: "hcmc",
      district: "quan9",
      address: "Nguyễn Xiển, Long Thạnh Mỹ, Quận 9",
      type: "Căn hộ cao cấp",
      price: "Từ 3.2 tỷ",
      priceValue: 3200000000,
      bedrooms: 2,
      bathrooms: 2,
      area: 75,
      features: ["Công viên 36ha", "Trường học liên cấp", "Bệnh viện Vinmec", "Shopping mall"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Đang bán",
      completion: "Q4/2024",
      developer: "Vingroup",
    },
    {
      id: 2,
      name: "Masteri Thảo Điền",
      location: "Quận 2, TP.HCM",
      city: "hcmc",
      district: "quan2",
      address: "159 Xa lộ Hà Nội, Thảo Điền, Quận 2",
      type: "Căn hộ cao cấp",
      price: "Từ 4.5 tỷ",
      priceValue: 4500000000,
      bedrooms: 2,
      bathrooms: 2,
      area: 70,
      features: ["View sông Sài Gòn", "Hồ bơi vô cực", "Gym & Spa", "Khu BBQ"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Sắp bàn giao",
      completion: "Q1/2025",
      developer: "Masterise Homes",
    },
    {
      id: 3,
      name: "Vinhomes Smart City",
      location: "Nam Từ Liêm, Hà Nội",
      city: "hanoi",
      district: "namtuliiem",
      address: "Đại lộ Thăng Long, Nam Từ Liêm, Hà Nội",
      type: "Căn hộ thông minh",
      price: "Từ 2.8 tỷ",
      priceValue: 2800000000,
      bedrooms: 2,
      bathrooms: 2,
      area: 65,
      features: ["Smart home", "Công viên Nhật Bản", "Trường quốc tế", "Hệ thống IoT"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Sẵn sàng",
      completion: "Q3/2024",
      developer: "Vingroup",
    },
    {
      id: 4,
      name: "Times City Hanoi",
      location: "Hai Bà Trưng, Hà Nội",
      city: "hanoi",
      district: "haibatrung",
      address: "458 Minh Khai, Hai Bà Trưng, Hà Nội",
      type: "Căn hộ cao cấp",
      price: "Từ 3.5 tỷ",
      priceValue: 3500000000,
      bedrooms: 3,
      bathrooms: 2,
      area: 85,
      features: ["Shopping mall", "Công viên nước", "Trường học", "Bệnh viện"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Sẵn sàng",
      completion: "Đã bàn giao",
      developer: "Vingroup",
    },
    {
      id: 5,
      name: "Monarchy Đà Nẵng",
      location: "Hải Châu, Đà Nẵng",
      city: "danang",
      district: "haichau",
      address: "Lê Duẩn, Hải Châu, Đà Nẵng",
      type: "Căn hộ cao cấp",
      price: "Từ 2.2 tỷ",
      priceValue: 2200000000,
      bedrooms: 2,
      bathrooms: 2,
      area: 60,
      features: ["View biển", "Hồ bơi rooftop", "Gym", "Spa"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Đang bán",
      completion: "Q2/2025",
      developer: "Monarchy Group",
    },
    {
      id: 6,
      name: "Saigon South Residences",
      location: "Quận 7, TP.HCM",
      city: "hcmc",
      district: "quan7",
      address: "Nguyễn Lương Bằng, Phú Mỹ Hưng, Quận 7",
      type: "Căn hộ cao cấp",
      price: "Từ 5.8 tỷ",
      priceValue: 5800000000,
      bedrooms: 3,
      bathrooms: 3,
      area: 95,
      features: ["Khu Phú Mỹ Hưng", "Trường quốc tế", "Golf course", "Marina"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Sắp mở bán",
      completion: "Q3/2025",
      developer: "Keppel Land",
    },
    {
      id: 7,
      name: "Imperia Garden",
      location: "Thanh Xuân, Hà Nội",
      city: "hanoi",
      district: "thanhxuan",
      address: "203 Nguyễn Huy Tưởng, Thanh Xuân, Hà Nội",
      type: "Căn hộ cao cấp",
      price: "Từ 3.8 tỷ",
      priceValue: 3800000000,
      bedrooms: 2,
      bathrooms: 2,
      area: 78,
      features: ["Vườn Nhật", "Hồ bơi 4 mùa", "Gym & Yoga", "Kids club"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Sẵn sàng",
      completion: "Đã bàn giao",
      developer: "Imperia Group",
    },
    {
      id: 8,
      name: "Landmark 81",
      location: "Bình Thạnh, TP.HCM",
      city: "hcmc",
      district: "binhthạnh",
      address: "720A Điện Biên Phủ, Bình Thạnh, TP.HCM",
      type: "Căn hộ siêu cao cấp",
      price: "Từ 8.5 tỷ",
      priceValue: 8500000000,
      bedrooms: 2,
      bathrooms: 2,
      area: 68,
      features: ["Tòa nhà cao nhất VN", "Sky bar", "Infinity pool", "Concierge 24/7"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Sẵn sàng",
      completion: "Đã bàn giao",
      developer: "Vinhomes",
    },
    {
      id: 9,
      name: "Sun Grand City",
      location: "Lương Yên, Hà Nội",
      city: "hanoi",
      district: "haibatrung",
      address: "69B Thụy Khuê, Lương Yên, Hà Nội",
      type: "Căn hộ cao cấp",
      price: "Từ 4.2 tỷ",
      priceValue: 4200000000,
      bedrooms: 3,
      bathrooms: 2,
      area: 88,
      features: ["View Hồ Tây", "Shopping mall", "Trường học", "Bệnh viện"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Đang bán",
      completion: "Q1/2025",
      developer: "Sun Group",
    },
    {
      id: 10,
      name: "Eco Green Saigon",
      location: "Quận 7, TP.HCM",
      city: "hcmc",
      district: "quan7",
      address: "Nguyễn Văn Linh, Tân Phong, Quận 7",
      type: "Căn hộ xanh",
      price: "Từ 3.9 tỷ",
      priceValue: 3900000000,
      bedrooms: 2,
      bathrooms: 2,
      area: 72,
      features: ["Công nghệ xanh", "Vườn treo", "Hệ thống lọc không khí", "Solar panel"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Sắp mở bán",
      completion: "Q4/2025",
      developer: "Eco Green",
    },
    {
      id: 11,
      name: "Goldmark City",
      location: "Bắc Từ Liêm, Hà Nội",
      city: "hanoi",
      district: "bactuliiem",
      address: "136 Hồ Tùng Mậu, Bắc Từ Liêm, Hà Nội",
      type: "Căn hộ cao cấp",
      price: "Từ 2.9 tỷ",
      priceValue: 2900000000,
      bedrooms: 2,
      bathrooms: 2,
      area: 70,
      features: ["Khu đô thị", "Trường học", "Bệnh viện", "Công viên"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Sẵn sàng",
      completion: "Đã bàn giao",
      developer: "Goldmark",
    },
    {
      id: 12,
      name: "Serenity Sky Villas",
      location: "Quận 3, TP.HCM",
      city: "hcmc",
      district: "quan3",
      address: "Võ Văn Tần, Quận 3, TP.HCM",
      type: "Sky Villa",
      price: "Từ 12.5 tỷ",
      priceValue: 12500000000,
      bedrooms: 4,
      bathrooms: 4,
      area: 150,
      features: ["Penthouse", "Sân vườn riêng", "Hồ bơi riêng", "View 360°"],
      image: "/placeholder.svg?height=300&width=400",
      status: "Đang bán",
      completion: "Q2/2025",
      developer: "Serenity Group",
    },
  ]

  // Cities and districts data
  const cities = [
    { value: "all", label: "Tất cả thành phố" },
    { value: "hcmc", label: "TP. Hồ Chí Minh" },
    { value: "hanoi", label: "Hà Nội" },
    { value: "danang", label: "Đà Nẵng" },
  ]

  const districts = {
    all: [{ value: "all", label: "Tất cả khu vực" }],
    hcmc: [
      { value: "all", label: "Tất cả quận/huyện" },
      { value: "quan1", label: "Quận 1" },
      { value: "quan2", label: "Quận 2" },
      { value: "quan3", label: "Quận 3" },
      { value: "quan7", label: "Quận 7" },
      { value: "quan9", label: "Quận 9" },
      { value: "binhthạnh", label: "Bình Thạnh" },
    ],
    hanoi: [
      { value: "all", label: "Tất cả quận/huyện" },
      { value: "haibatrung", label: "Hai Bà Trưng" },
      { value: "namtuliiem", label: "Nam Từ Liêm" },
      { value: "bactuliiem", label: "Bắc Từ Liêm" },
      { value: "thanhxuan", label: "Thanh Xuân" },
    ],
    danang: [
      { value: "all", label: "Tất cả quận/huyện" },
      { value: "haichau", label: "Hải Châu" },
      { value: "sontra", label: "Sơn Trà" },
      { value: "nguhanhson", label: "Ngũ Hành Sơn" },
    ],
  }

  const priceRanges = [
    { value: "all", label: "Tất cả mức giá" },
    { value: "under3", label: "Dưới 3 tỷ" },
    { value: "3to5", label: "3-5 tỷ" },
    { value: "5to8", label: "5-8 tỷ" },
    { value: "above8", label: "Trên 8 tỷ" },
  ]

  const propertyTypes = [
    { value: "all", label: "Tất cả loại hình" },
    { value: "apartment", label: "Căn hộ" },
    { value: "villa", label: "Villa" },
    { value: "townhouse", label: "Nhà phố" },
    { value: "office", label: "Văn phòng" },
  ]

  const bedroomOptions = [
    { value: "all", label: "Tất cả" },
    { value: "1", label: "1 phòng" },
    { value: "2", label: "2 phòng" },
    { value: "3", label: "3 phòng" },
    { value: "4+", label: "4+ phòng" },
  ]

  const bathroomOptions = [
    { value: "all", label: "Tất cả" },
    { value: "1", label: "1 phòng" },
    { value: "2", label: "2 phòng" },
    { value: "3", label: "3 phòng" },
    { value: "4+", label: "4+ phòng" },
  ]

  const areaOptions = [
    { value: "all", label: "Tất cả diện tích" },
    { value: "under50", label: "Dưới 50m²" },
    { value: "50to80", label: "50-80m²" },
    { value: "80to120", label: "80-120m²" },
    { value: "above120", label: "Trên 120m²" },
  ]

  // Filter logic
  const filteredProperties = useMemo(() => {
    return allProperties.filter((property) => {
      const matchesSearch =
        property.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        property.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        property.developer.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesCity = selectedCity === "all" || property.city === selectedCity
      const matchesDistrict = selectedDistrict === "all" || property.district === selectedDistrict

      const matchesPrice =
        selectedPriceRange === "all" ||
        (() => {
          switch (selectedPriceRange) {
            case "under3":
              return property.priceValue < 3000000000
            case "3to5":
              return property.priceValue >= 3000000000 && property.priceValue < 5000000000
            case "5to8":
              return property.priceValue >= 5000000000 && property.priceValue < 8000000000
            case "above8":
              return property.priceValue >= 8000000000
            default:
              return true
          }
        })()

      const matchesType = selectedType === "all" || property.type.toLowerCase().includes(selectedType.toLowerCase())

      const matchesBedrooms =
        selectedBedrooms === "all" ||
        (selectedBedrooms === "4+" ? property.bedrooms >= 4 : property.bedrooms === Number.parseInt(selectedBedrooms))

      const matchesBathrooms =
        selectedBathrooms === "all" ||
        (selectedBathrooms === "4+"
          ? property.bathrooms >= 4
          : property.bathrooms === Number.parseInt(selectedBathrooms))

      const matchesArea =
        selectedArea === "all" ||
        (() => {
          switch (selectedArea) {
            case "under50":
              return property.area < 50
            case "50to80":
              return property.area >= 50 && property.area < 80
            case "80to120":
              return property.area >= 80 && property.area < 120
            case "above120":
              return property.area >= 120
            default:
              return true
          }
        })()

      return (
        matchesSearch &&
        matchesCity &&
        matchesDistrict &&
        matchesPrice &&
        matchesType &&
        matchesBedrooms &&
        matchesBathrooms &&
        matchesArea
      )
    })
  }, [
    searchTerm,
    selectedCity,
    selectedDistrict,
    selectedPriceRange,
    selectedType,
    selectedBedrooms,
    selectedBathrooms,
    selectedArea,
  ])

  // Pagination logic
  const totalPages = Math.ceil(filteredProperties.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedProperties = filteredProperties.slice(startIndex, startIndex + itemsPerPage)

  // Reset district when city changes
  const handleCityChange = (city: string) => {
    setSelectedCity(city)
    setSelectedDistrict("all")
    setCurrentPage(1)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="py-12 bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-950/20 dark:to-red-900/20">
        <div className="container mx-auto px-4">
          <FadeIn>
            <Link href="/" className="inline-flex items-center text-orange-600 hover:text-orange-700 mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Quay lại trang chủ
            </Link>
            <Badge className="mb-4 bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300">
              BẤT ĐỘNG SẢN VIỆT NAM
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Bất động sản Việt Nam</h1>
            <p className="text-xl text-muted-foreground max-w-3xl">
              Khám phá những dự án bất động sản hàng đầu tại các thành phố lớn của Việt Nam với đa dạng loại hình và mức
              giá.
            </p>
          </FadeIn>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="py-8 bg-muted/30">
        <div className="container mx-auto px-4">
          <FadeIn>
            <div className="bg-white dark:bg-gray-900 rounded-lg p-6 shadow-sm">
              {/* Search Bar */}
              <div className="flex flex-col lg:flex-row gap-4 mb-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input
                      placeholder="Tìm kiếm theo tên dự án, vị trí, chủ đầu tư..."
                      className="pl-10"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                <Button
                  variant="outline"
                  onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                  className="lg:w-auto"
                >
                  <Filter className="w-4 h-4 mr-2" />
                  Lọc nâng cao
                  <ChevronDown
                    className={`w-4 h-4 ml-2 transition-transform ${showAdvancedFilters ? "rotate-180" : ""}`}
                  />
                </Button>
              </div>

              {/* Basic Filters */}
              <div className="grid md:grid-cols-4 gap-4 mb-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Thành phố</label>
                  <Select value={selectedCity} onValueChange={handleCityChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {cities.map((city) => (
                        <SelectItem key={city.value} value={city.value}>
                          {city.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Khu vực</label>
                  <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {(districts[selectedCity as keyof typeof districts] || districts.all).map((district) => (
                        <SelectItem key={district.value} value={district.value}>
                          {district.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Mức giá</label>
                  <Select value={selectedPriceRange} onValueChange={setPriceRange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {priceRanges.map((range) => (
                        <SelectItem key={range.value} value={range.value}>
                          {range.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Loại hình</label>
                  <Select value={selectedType} onValueChange={setSelectedType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {propertyTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Advanced Filters */}
              {showAdvancedFilters && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="grid md:grid-cols-3 gap-4 pt-4 border-t"
                >
                  <div>
                    <label className="text-sm font-medium mb-2 block">Số phòng ngủ</label>
                    <Select value={selectedBedrooms} onValueChange={setSelectedBedrooms}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {bedroomOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Số phòng tắm</label>
                    <Select value={selectedBathrooms} onValueChange={setSelectedBathrooms}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {bathroomOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Diện tích</label>
                    <Select value={selectedArea} onValueChange={setSelectedArea}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {areaOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </motion.div>
              )}

              {/* Results Summary */}
              <div className="flex items-center justify-between mt-4 pt-4 border-t text-sm text-muted-foreground">
                <span>
                  Hiển thị {startIndex + 1}-{Math.min(startIndex + itemsPerPage, filteredProperties.length)} trong tổng
                  số {filteredProperties.length} dự án
                </span>
                {(searchTerm ||
                  selectedCity !== "all" ||
                  selectedDistrict !== "all" ||
                  selectedPriceRange !== "all" ||
                  selectedType !== "all" ||
                  selectedBedrooms !== "all" ||
                  selectedBathrooms !== "all" ||
                  selectedArea !== "all") && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setSearchTerm("")
                      setSelectedCity("all")
                      setSelectedDistrict("all")
                      setPriceRange("all")
                      setSelectedType("all")
                      setSelectedBedrooms("all")
                      setSelectedBathrooms("all")
                      setSelectedArea("all")
                      setCurrentPage(1)
                    }}
                  >
                    Xóa bộ lọc
                  </Button>
                )}
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* Properties Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {paginatedProperties.length > 0 ? (
            <>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                {paginatedProperties.map((property, index) => (
                  <ScaleIn key={property.id} delay={index * 0.1}>
                    <motion.div whileHover={{ y: -10 }}>
                      <Card className="overflow-hidden h-full">
                        <div className="relative">
                          <motion.div whileHover={{ scale: 1.1 }}>
                            <Image
                              src={property.image || "/placeholder.svg"}
                              alt={property.name}
                              width={400}
                              height={300}
                              className="w-full h-48 object-cover"
                            />
                          </motion.div>
                          <div className="absolute top-4 left-4">
                            <Badge className="bg-white/90 text-gray-900">{property.developer}</Badge>
                          </div>
                          <div className="absolute top-4 right-4">
                            <Badge
                              variant={property.status === "Sẵn sàng" ? "default" : "secondary"}
                              className={property.status === "Sẵn sàng" ? "bg-green-600" : ""}
                            >
                              {property.status}
                            </Badge>
                          </div>
                        </div>

                        <CardHeader>
                          <div className="flex justify-between items-start">
                            <div>
                              <CardTitle className="text-lg mb-2">{property.name}</CardTitle>
                              <p className="text-muted-foreground flex items-center text-sm">
                                <MapPin className="w-4 h-4 mr-1" />
                                {property.location}
                              </p>
                            </div>
                            <div className="text-right">
                              <div className="text-xl font-bold text-orange-600">{property.price}</div>
                              <div className="text-xs text-muted-foreground">{property.type}</div>
                            </div>
                          </div>
                        </CardHeader>

                        <CardContent>
                          <div className="space-y-4">
                            <div className="grid grid-cols-3 gap-4 text-sm">
                              <div className="flex items-center">
                                <Bed className="w-4 h-4 mr-1 text-muted-foreground" />
                                <span>{property.bedrooms} PN</span>
                              </div>
                              <div className="flex items-center">
                                <Bath className="w-4 h-4 mr-1 text-muted-foreground" />
                                <span>{property.bathrooms} PT</span>
                              </div>
                              <div className="flex items-center">
                                <Square className="w-4 h-4 mr-1 text-muted-foreground" />
                                <span>{property.area}m²</span>
                              </div>
                            </div>

                            <div>
                              <h4 className="font-semibold mb-2 text-sm">Tiện ích nổi bật:</h4>
                              <div className="grid grid-cols-1 gap-1">
                                {property.features.slice(0, 3).map((feature, idx) => (
                                  <div key={idx} className="flex items-center text-xs text-muted-foreground">
                                    <CheckCircle className="w-3 h-3 mr-1 text-green-600 flex-shrink-0" />
                                    {feature}
                                  </div>
                                ))}
                                {property.features.length > 3 && (
                                  <div className="text-xs text-muted-foreground">
                                    +{property.features.length - 3} tiện ích khác
                                  </div>
                                )}
                              </div>
                            </div>

                            <div className="flex gap-2 pt-4">
                              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="flex-1">
                                <Link href={`/products/${property.city}/${property.id}`}>
                                  <Button className="w-full bg-orange-600 hover:bg-orange-700 text-sm">
                                    Xem chi tiết
                                  </Button>
                                </Link>
                              </motion.div>
                              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                                <Button variant="outline" size="sm">
                                  Liên hệ
                                </Button>
                              </motion.div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  </ScaleIn>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <FadeIn>
                  <div className="flex items-center justify-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                    >
                      <ChevronLeft className="w-4 h-4" />
                      Trước
                    </Button>

                    <div className="flex space-x-1">
                      {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                        <Button
                          key={page}
                          variant={currentPage === page ? "default" : "outline"}
                          size="sm"
                          onClick={() => setCurrentPage(page)}
                          className="w-10"
                        >
                          {page}
                        </Button>
                      ))}
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                    >
                      Sau
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </FadeIn>
              )}
            </>
          ) : (
            <div className="text-center py-12">
              <Building className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Không tìm thấy dự án</h3>
              <p className="text-muted-foreground mb-4">Thử thay đổi bộ lọc hoặc từ khóa tìm kiếm</p>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("")
                  setSelectedCity("all")
                  setSelectedDistrict("all")
                  setPriceRange("all")
                  setSelectedType("all")
                  setSelectedBedrooms("all")
                  setSelectedBathrooms("all")
                  setSelectedArea("all")
                  setCurrentPage(1)
                }}
              >
                Xóa bộ lọc
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-gradient-to-r from-orange-600 to-red-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <FadeIn>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Tìm hiểu thêm về dự án</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
              Liên hệ với chuyên gia để được tư vấn chi tiết về các dự án bất động sản hàng đầu Việt Nam
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button size="lg" className="bg-white text-orange-600 hover:bg-gray-100">
                  Tư vấn miễn phí ngay
                </Button>
              </motion.div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-orange-600 bg-transparent"
                >
                  Tải brochure dự án
                </Button>
              </motion.div>
            </div>
          </FadeIn>
        </div>
      </section>
    </div>
  )
}
